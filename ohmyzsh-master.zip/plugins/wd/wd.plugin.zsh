# WARP DIRECTORY
# ==============
# oh-my-zsh plugin
#
# @github.com/mfaerevaag/wd

eval "wd() { source '${0:A:h}/wd.sh' }"
